# Deep Dive: Upgraded Machine ID (Device Fingerprinting)

This document provides a highly technical, code-level analysis of the **Upgraded Machine ID** system implemented in the Shim extension. It replaces the old cloud-sync UUID method with a mathematically complex, hardware-bound cryptographic hash.

---

## 1. The Code-Level Flow (How it's Generated)

The core logic resides in `worker.js` inside the `getCompositeDeviceId()` function. It operates through a multi-stage cryptographic pipeline:

### Stage 1: The UUID Anchor (`chrome.storage.local`)
```javascript
chrome.storage.local.get(['deviceUuid'], async (result) => {
    let uuid = result.deviceUuid;
    if (!uuid) {
        uuid = crypto.randomUUID();
        chrome.storage.local.set({ deviceUuid: uuid });
    }
```
**Technical Analysis:**
We use `crypto.randomUUID()` to generate a V4 UUID (e.g., `123e4567-e89b-12d3-a456-426614174000`). This relies on the browser's cryptographically secure pseudorandom number generator (CSPRNG).
Crucially, this is saved to `chrome.storage.local`. This ties the UUID to the physical Google Chrome user data directory on the host's hard drive (`%LOCALAPPDATA%\Google\Chrome\User Data\Default`). It will never sync across the internet.

### Stage 2: Hardware Entropy Gathering
```javascript
const entropyStr = [
    navigator.hardwareConcurrency || 'unknown',
    navigator.deviceMemory || 'unknown',
    "SHIM_SECURE_SALT_v2_9X2P" // Static Salt
].join('|');
```
**Technical Analysis:**
- `hardwareConcurrency`: Returns the number of logical processors (threads) available to run threads on the user's computer. (e.g., `16`).
- `deviceMemory`: Returns the approximate amount of device memory in gigabytes (e.g., `8` or `16`). 
- **The Omission Strategy:** Notice that we *intentionally removed* `navigator.userAgent`, `navigator.language`, and timezone data. Browsers update frequently, and students travel. If we included these, their hash would change every time Google Chrome released a new update, locking them out of their accounts. By strictly using physical hardware constraints, the hash remains permanent until they physically upgrade their RAM or CPU.
- **The Salt:** `"SHIM_SECURE_SALT_v2_9X2P"` is a cryptographic salt. Even if a hacker knows the student has 16 cores and 16GB of RAM, they cannot compute the resulting hash without knowing this secret string embedded in the obfuscated code.

### Stage 3: The SHA-256 Digest
```javascript
const msgBuffer = new TextEncoder().encode(entropyStr);
const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
const hashArray = Array.from(new Uint8Array(hashBuffer));
const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
```
**Technical Analysis:**
- We encode the string (e.g., `16|16|SHIM_SECURE_SALT_v2_9X2P`) into a `Uint8Array` of UTF-8 bytes.
- We pass the bytes to the Web Crypto API (`crypto.subtle.digest`). This is a native, hardware-accelerated C++ implementation within V8, meaning it executes in less than a millisecond and is immune to timing attacks.
- We map the resulting 32-byte ArrayBuffer into a 64-character hexadecimal string.

### Stage 4: Assembly
```javascript
resolve(`${uuid}.${hashHex}`);
```
The final output perfectly combines the uniqueness of a CSPRNG with the physical constraints of the host machine:
`123e4567-e89b-12d3-a456-426614174000.e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

---

## 2. Threat Modeling & Attack Vectors

If an attacker tries to steal or share an Ultra License Key, here is how the system defeats them:

### Attack Vector A: The "Copy-Paste" Attack
**The Attack:** Student A buys a key. Student A copies the key and messages it to Student B.
**The Defense:** Student B's extension generates a brand new UUID Anchor. Even if they have the exact same laptop model as Student A, the UUID halves of the Composite ID won't match. The backend rejects Student B with a `403 Forbidden`.

### Attack Vector B: The "Storage Extraction" Attack
**The Attack:** Student A opens Chrome DevTools, runs `chrome.storage.local.get()`, extracts their UUID Anchor, and sends both the License Key and the UUID Anchor to Student B. Student B writes a script to inject that UUID into their own browser.
**The Defense:** 
1. **Obfuscation Defense:** Our `debugProtection: true` obfuscation will instantly crash Student A's browser tab the second they press F12, making extraction nearly impossible for average users.
2. **Hardware Hash Defense:** Even if Student B successfully injects the stolen UUID Anchor, Student B's laptop must have the exact same number of CPU cores and RAM as Student A's laptop. If Student B has an 8-core CPU and Student A has a 16-core CPU, the `EntropyHash` half of the composite ID will change! 
3. The backend receives `StolenUUID.DifferentHash`. The database expects `StolenUUID.OriginalHash`. They don't match. Request denied.

### Attack Vector C: The "API Replay" Attack
**The Attack:** A hacker intercepts the HTTP requests using Wireshark or Proxyman. They steal the `Authorization: Bearer` token and the `X-Device-ID` header. They use Postman or a Python script to spam the backend directly, bypassing the extension.
**The Defense:** The hacker can successfully authenticate. However, the FastAPI backend utilizes Rate Limiting (`@limiter.limit("20/minute")`). Even with perfectly forged headers, they are bound by the strict API limits, making it impossible to spam or sell access to your API endpoints at scale.

---

## 3. The Backend Verification Logic (FastAPI)

When the extension hits the backend (`POST /verify-key` or `POST /api/chat`), the backend enforces the lock:

```python
# During /verify-key
if not license.device_id:
    # First time use: Permanently bind the UUID.HASH to the key
    license.device_id = body.deviceId
    db.commit()
elif license.device_id != body.deviceId:
    # Any subsequent use: The exact UUID and exact Hardware Hash must match perfectly.
    raise HTTPException(status_code=403, detail="Key is bound to another device")
```

**The Trade-Off:** Because this system is mathematically uncompromising, if a legitimate student upgrades their laptop's RAM from 8GB to 16GB, their `EntropyHash` will change, and they will be locked out of their account. You must implement a `/admin/reset-device` endpoint in your backend to handle these support tickets by setting `license.device_id = NULL`.
