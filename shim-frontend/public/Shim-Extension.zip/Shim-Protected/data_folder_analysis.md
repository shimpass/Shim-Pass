# Deep-Dive Analysis: The `data/inject/` Directory

The `data/` folder (and specifically `data/inject/`) contains the absolute core of Shim's stealth and bypass capabilities. These files are injected directly into the target webpage (the exam platform) either into the isolated execution environment or the "main" execution environment.

Here is a deep, file-by-file analysis of how these scripts operate:

## 1. `anti-anti-debug.js`
**Execution Context:** Main World (Injected directly into the DOM).
**Purpose:** Defeats proctoring software's attempts to detect if the student has opened Developer Tools.
**How it Works (Line-by-Line Logic):**
- It caches the original browser functions (`console.log`, `console.table`, `console.clear`, `setInterval`, `Function.prototype.toString`).
- **`console.log` override:** Proctoring scripts often try to log a custom object with a "getter" attached to it. If the developer tools are open, the browser automatically evaluates the object to display it, which triggers the getter, alerting the proctoring script. This file intercepts all `console.log` calls, scans the arguments, and if it detects custom getters or massive object arrays (Performance Detectors), it redacts them (prints "Redacted Getter" instead of evaluating it).
- **`setInterval` override:** Proctoring scripts often run `setInterval(debugger, 100)` to freeze the browser if DevTools are open. This file intercepts `setInterval`, converts the function to a string, checks if it contains the word `debugger`, and if so, safely drops it to prevent the freeze loop.

## 2. `screenshare.js` & `screenshare-bridge.js`
**Execution Context:** Main World.
**Purpose:** The ultimate screen-share bypass (Restricted to Ultra Tier).
**How it Works:**
- `screenshare-bridge.js` safely bridges communication between the extension's isolated world and the main world DOM. It fetches the user's `tier` (e.g., "ultra") from local storage and attaches it to a hidden DOM element dataset.
- `screenshare.js` checks this dataset. If `tier === 'ultra'`, it executes its payload.
- It intercepts the browser's native `navigator.mediaDevices.getDisplayMedia` function (the function the browser uses to ask for permission to share the screen).
- Instead of showing the real screen to the proctoring software, it injects a custom floating UI into the page allowing the student to pick a "Safe Window" or a "Frozen Frame".
- It returns a mocked MediaStream object containing the safe window, completely tricking the exam software.

## 3. `customPaste.js`
**Execution Context:** Isolated World.
**Purpose:** Ghost Typing (Hardware-level paste simulation).
**How it Works:**
- Proctoring software easily detects `Ctrl+V` or right-click pastes. 
- When a user highlights text and requests an AI answer, the AI answer is sent to `customPaste.js`.
- If the user is on the Pro or Ultra tier, `customPaste.js` sends a message to `worker.js`, which then talks to `com.shim.typer` (a native host application on the OS).
- The native host application simulates real, physical keyboard presses. The proctoring software sees genuine `keydown`, `keypress`, and `keyup` events matching human typing speed, making it impossible to flag as a paste.

## 4. `chatbot.js` & `content.js`
**Execution Context:** Isolated World.
**Purpose:** The Invisible AI Overlay.
**How it Works:**
- `content.js` handles the initialization and listens for the exact keyboard shortcut or mouse clicks required to summon the UI.
- `chatbot.js` builds the DOM elements for the AI UI. It specifically creates elements using deeply randomized class names or utilizing the "Shadow DOM" so that proctoring software (which constantly scans the DOM for forbidden words like "ChatGPT" or "AI") cannot detect the UI's existence.
- It captures the text the user highlighted, sends it to `worker.js`, retrieves the AI response, and formats it beautifully within the hidden overlay.

## 5. `copyOverride.js` & `rightclickmenu.js`
**Execution Context:** Main World & Isolated World.
**Purpose:** Defeats anti-copy restrictions.
**How it Works:**
- Exam platforms often block right-clicking or copying text.
- `copyOverride.js` intercepts event listeners for `copy`, `cut`, `paste`, and `contextmenu`. It calls `event.stopPropagation()` to stop the exam platform from knowing the user performed these actions, allowing the student to freely copy questions without being flagged.

## 6. `exam.js`
**Execution Context:** Main World.
**Purpose:** Exam Platform Specific Patches.
**How it Works:**
- Contains targeted patches for specific proctoring vendors (e.g., disabling specific event listeners that Mettl or Examly inject into the `window` object).

## 7. `isolated.js` & `main.js`
**Execution Context:** Split.
**Purpose:** Orchestrators.
**How it Works:**
- These files handle the secure message passing between the dangerous Main World (where the proctoring script lives) and the secure Isolated World (where the extension's secrets live). They use secure `window.postMessage` channels with unique, randomized signature hashes to prevent the proctoring script from intercepting or forging messages.
