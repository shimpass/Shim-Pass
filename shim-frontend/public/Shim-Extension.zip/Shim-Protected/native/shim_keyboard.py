#!/usr/bin/env python3

import sys
import json
import struct
import time
import os

# Try to import pynput, fall back to logging if not installed
try:
    from pynput.keyboard import Controller, Key
    keyboard = Controller()
    HAS_PYNPUT = True
except ImportError:
    HAS_PYNPUT = False

# Ensure standard I/O is in binary mode on Windows
if sys.platform == "win32":
    import msvcrt
    msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)

# Read a message from standard input
def get_message():
    raw_length = sys.stdin.buffer.read(4)
    if len(raw_length) == 0:
        sys.exit(0)
    message_length = struct.unpack('@I', raw_length)[0]
    message = sys.stdin.buffer.read(message_length).decode('utf-8')
    return json.loads(message)

# Send an encoded message to standard output
def send_message(message_content):
    encoded_content = json.dumps(message_content).encode('utf-8')
    encoded_length = struct.pack('@I', len(encoded_content))
    sys.stdout.buffer.write(encoded_length)
    sys.stdout.buffer.write(encoded_content)
    sys.stdout.buffer.flush()

def type_text(text):
    if not HAS_PYNPUT:
        send_message({"status": "error", "message": "pynput is not installed. Please run: pip install pynput"})
        return

    # Simulate physical keystrokes
    try:
        for char in text:
            # Handle special characters or newlines
            if char == '\n':
                keyboard.press(Key.enter)
                keyboard.release(Key.enter)
            elif char == '\t':
                keyboard.press(Key.tab)
                keyboard.release(Key.tab)
            else:
                keyboard.type(char)
            # Add a microscopic delay to simulate human typing and prevent buffer overflow
            time.sleep(0.005)
        
        send_message({"status": "success", "message": "Text typed successfully."})
    except Exception as e:
        send_message({"status": "error", "message": str(e)})

if __name__ == '__main__':
    while True:
        try:
            msg = get_message()
            if msg.get('action') == 'typeText':
                text_to_type = msg.get('text', '')
                type_text(text_to_type)
            elif msg.get('action') == 'ping':
                send_message({"status": "success", "message": "Host is alive.", "has_pynput": HAS_PYNPUT})
            else:
                send_message({"status": "error", "message": "Unknown action."})
        except Exception as e:
            # Fail silently to avoid breaking the pipe
            pass
