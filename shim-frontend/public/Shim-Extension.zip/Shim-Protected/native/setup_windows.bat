@echo off
echo ========================================================
echo Shim Native Messaging Setup for Windows
echo ========================================================
echo.

:: Check for Python installation
set "PYTHON_CMD="
py --version >nul 2>&1
IF %ERRORLEVEL% EQU 0 (
    set "PYTHON_CMD=py"
) ELSE (
    python --version >nul 2>&1
    IF %ERRORLEVEL% EQU 0 (
        set "PYTHON_CMD=python"
    )
)

IF "%PYTHON_CMD%"=="" (
    echo [ERROR] Python is not installed or not in your system PATH.
    echo Please install Python from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

echo [OK] Python is installed.
echo Installing required python packages (pynput)...
%PYTHON_CMD% -m pip install pynput

echo.
echo Please go to chrome://extensions/ in Chrome.
echo Find the Shim extension and look for the 'ID: aaaaaaaabbbbbbbbccccccccdddddddd' string.
set /p EXT_ID="Paste your Extension ID here: "

if "%EXT_ID%"=="" (
    echo [ERROR] Extension ID cannot be empty.
    pause
    exit /b 1
)

echo.
echo Registering Native Messaging Host with Google Chrome...

:: Create a specific host manifest for Windows
set "MANIFEST_PATH=%~dp0host_manifest_win.json"
set "BAT_PATH=%~dp0shim_keyboard.bat"

:: Escape backslashes for JSON
set "ESCAPED_BAT_PATH=%BAT_PATH:\=\\%"

(echo {) > "%MANIFEST_PATH%"
(echo   "name": "com.shim.keyboard",) >> "%MANIFEST_PATH%"
(echo   "description": "Shim Native Keyboard Host",) >> "%MANIFEST_PATH%"
(echo   "path": "%ESCAPED_BAT_PATH%",) >> "%MANIFEST_PATH%"
(echo   "type": "stdio",) >> "%MANIFEST_PATH%"
(echo   "allowed_origins": [) >> "%MANIFEST_PATH%"
(echo     "chrome-extension://%EXT_ID%/") >> "%MANIFEST_PATH%"
(echo   ]) >> "%MANIFEST_PATH%"
(echo }) >> "%MANIFEST_PATH%"

:: Create the executable batch file wrapper for the python script
(echo @echo off) > "%BAT_PATH%"
(echo %PYTHON_CMD% "%~dp0shim_keyboard.py" %%*) >> "%BAT_PATH%"

:: Write to the Windows Registry
REG ADD "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.shim.keyboard" /ve /t REG_SZ /d "%MANIFEST_PATH%" /f

IF %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Shim Native Messaging Host installed successfully!
    echo Please go to chrome://extensions and reload the Shim extension.
) ELSE (
    echo.
    echo [ERROR] Failed to write to the registry. Please run this script as Administrator.
)

pause
