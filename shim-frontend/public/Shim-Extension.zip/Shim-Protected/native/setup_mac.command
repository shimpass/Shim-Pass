#!/bin/bash

echo "========================================="
echo "  Shim Native Keyboard Setup for Mac"
echo "========================================="
echo ""

# Get the absolute path of the directory where this script is located
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PYTHON_SCRIPT="$DIR/shim_keyboard.py"
MANIFEST_FILE="$DIR/host_manifest.json"
CHROME_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"

# Make the python script executable
chmod +x "$PYTHON_SCRIPT"

echo "1. Installing Python dependencies..."
pip3 install pynput

echo ""
echo "2. Please go to chrome://extensions/ in Chrome."
echo "   Find the Shim (Google Docs Offline) extension."
echo "   Look for the 'ID: aaaaaaaabbbbbbbbccccccccdddddddd' string."
read -p "   Paste your Extension ID here: " EXT_ID

if [ -z "$EXT_ID" ]; then
    echo "Error: Extension ID cannot be empty."
    exit 1
fi

echo ""
echo "3. Updating manifest file..."
cat > "$MANIFEST_FILE" << EOF
{
  "name": "com.shim.keyboard",
  "description": "Shim Native Keyboard Host",
  "path": "$PYTHON_SCRIPT",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://$EXT_ID/"
  ]
}
EOF

echo "4. Installing manifest to Chrome Native Messaging directory..."
mkdir -p "$CHROME_DIR"
cp "$MANIFEST_FILE" "$CHROME_DIR/com.shim.keyboard.json"

echo ""
echo "========================================="
echo "Setup Complete!"
echo "If this is your first time using pynput, macOS will ask you"
echo "to grant Accessibility Permissions to Chrome or Terminal."
echo "Please go to System Settings -> Privacy & Security -> Accessibility"
echo "and ensure Google Chrome (and potentially Terminal) is toggled ON."
echo "========================================="
echo ""
read -p "Press Enter to exit..."
