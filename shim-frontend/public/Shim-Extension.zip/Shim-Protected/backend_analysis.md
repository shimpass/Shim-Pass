# Backend Analysis & Action Items

I have analyzed your `shim-backend` codebase and compared it against the extension's security requirements. Your backend is built with FastAPI, uses SQLite (`shim.db`), and successfully integrates AI streaming (Gemini with a Groq fallback). 

Overall, the foundation is excellent. However, to fully sync with the advanced security logic we just built into the Extension, you need to implement a few critical updates.

## Current State of the Backend
- **Framework:** FastAPI running via Uvicorn.
- **Database:** SQLite (`shim.db`) using SQLAlchemy (`models.py`, `schemas.py`, `database.py`).
- **Authentication:** Validates `LicenseKey` for active status and expiration.
- **AI Integration:** Implements `unified_chat_stream` securely on the server-side, hiding your API keys.

---

## What You Need to Change / Add

Here is the exact checklist of what you need to modify in your backend to achieve perfect synchronization with the extension:

### 1. Update `/verify-key` Exceptions (`routers/extension.py`)
**The Issue:** Your backend currently returns a `200 OK` status with `{"valid": False}` when a key is invalid. The updated extension now expects HTTP error codes (`401` or `403`) to properly trigger its failure logic.
**The Fix:**
Change the logic in `routers/extension.py` to raise `HTTPException` instead of returning dictionaries:
```python
@router.post("/verify-key", response_model=schemas.VerifyKeyResponse)
@limiter.limit("5/minute")
def verify_key(request: Request, body: schemas.VerifyKeyRequest, db: Session = Depends(get_db)):
    license = db.query(models.LicenseKey).filter(models.LicenseKey.key == body.key).first()
    
    if not license or not license.is_active:
        raise HTTPException(status_code=401, detail="Invalid or inactive key")
        
    if license.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="Key has expired")
        
    if not license.device_id:
        license.device_id = body.deviceId
        db.commit()
    elif license.device_id != body.deviceId:
        # Note: The extension now sends "UUID.HASH". This strictly locks to hardware.
        raise HTTPException(status_code=403, detail="Key is bound to another device")
        
    return {"valid": True, "tier": license.tier, "expires": license.expires_at}
```

### 2. Update `/api/chat` Device ID Validation (`routers/extension.py`)
**The Issue:** You are currently passing `x_device_id` as a Header, which is perfect. However, you need to ensure the validation logic correctly rejects requests if the `x_device_id` doesn't match the database.
**The Fix:**
Ensure your logic strictly checks:
```python
    if license.device_id != x_device_id:
        raise HTTPException(status_code=403, detail="Key bound to another device")
```

### 3. Add a "Reset Device ID" Admin Endpoint
**The Issue:** Because the extension now uses a composite Hardware Hash (`UUID.HASH`), if a student buys a new laptop or upgrades their RAM, their hash will change, and they will be locked out of their account.
**The Fix:**
You need to create an admin endpoint (e.g., in `routers/admin.py`) or a button on your Next.js dashboard that allows you to reset a user's device lock.
```python
@router.post("/admin/reset-device/{license_key}")
def reset_device(license_key: str, db: Session = Depends(get_db)):
    # Verify Admin Auth here...
    license = db.query(models.LicenseKey).filter(models.LicenseKey.key == license_key).first()
    if license:
        license.device_id = None
        db.commit()
        return {"status": "success", "message": "Device ID reset. User can now log in on a new device."}
```

### 4. Production Database Migration
**The Issue:** You are currently using SQLite (`shim.db`), which is great for local testing but will not work well on Render (because Render's free/standard instances have ephemeral file systems, meaning your database will be wiped every time the server restarts).
**The Fix:**
Before deploying, change your `DATABASE_URL` in `.env` to a managed PostgreSQL database URL provided by Render.

---

### Summary
Your backend is 90% complete. Once you implement the `HTTPException` raises in `verify-key`, build the reset-device endpoint, and migrate to PostgreSQL for production, the entire system (Extension + Backend) will be an impregnable fortress ready for deployment.
