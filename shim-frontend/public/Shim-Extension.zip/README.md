<img width="1500" height="500" alt="Shim Banner" src="https://github.com/user-attachments/assets/7369dd86-838d-4fdc-abdd-6b41a9b14aed" />

# <i>**`Free`** Shim Extension - Ultimate Stealth Edition</i>

> **Shim Pro** - [Click here to see Pro features and benefits](https://shim.tech/pro)

This Chrome extension is an advanced, bleeding-edge bypass tool for students taking tests on the **`supported portals`**, **`HackerRank`**, **`NPTEL`**, and `other high-end exam portals` (like Proctorio, Honorlock, and Examly) that heavily restrict your browser abilities.

### [**Make sure to visit our website for the best experience!**](https://freeshim.vercel.app) 🌐

<samp>
  
> [!IMPORTANT]
> **Free Users**: No sign-up needed! Configure your own AI API key by clicking the extension icon and going to the **Settings** tab.  
> Supported providers: OpenAI, Google Gemini, DeepSeek, and custom endpoints.
> 
> **Want a hassle-free experience?** Upgrade to Pro by visiting **shim.tech/pro** for AI managed by Shim (GPT-5.1), increased rate limits, and a Secure Browser with built-in Exam Helper access!  

> [!WARNING]
> **Educational Purposes Only**: This extension is intended for educational purposes. Please use it responsibly and ethically.  
> We are not responsible for any actions taken, and we do not encourage or promote cheating in any way.  
> Be cautious when using the extension to maintain academic integrity.

## ✨ Ultimate Stealth Features

Shim has been engineered to defeat the highest tiers of enterprise anti-cheat via mathematical undetectability.

- **`OS-Level Keystroke Injection (isTrusted Bypass)`** : Bypasses advanced JavaScript keyboard traps by using a Native Messaging Python Host to simulate physical OS-level keystrokes. Exam portals will see `isTrusted: true` as if a human is physically typing.
- **`Prototype Poisoning Protection`** : The UI is injected using a "pristine" `attachShadow` reference stolen from a sandboxed iframe. Even if the exam platform monkey-patches the main window to spy on extensions, Shim remains completely invisible.
- **`Extension ID Cloaking`** : Uses Chrome's `declarativeNetRequest` engine to instantly block outbound network requests attempting to scan your browser for the Shim extension ID.
- **`Dynamic IP Sniffing`** : Intercepts and filters network traffic dynamically to bypass backend restrictions from Examly and other platforms.
- **`WebRTC Screenshare Bypass`** : Bypasses fullscreen screenshare requirements by overriding `navigator.mediaDevices.getDisplayMedia` natively.
- **`Stealth Chatbot Overlay`** : A draggable AI Chatbot UI that perfectly mimics Google Keep. Features auto-adapting **Light/Dark Mode** and a manual theme toggle.
- **`Pasting When Restricted`** : Quickly paste answers via drag-and-drop or typing simulation when native pasting is disabled.
- **`Solve MCQ & Tab Switching Bypass`** : Search MCQs by selecting text and prevent unwanted tab switch restrictions.

## ⬇️ Installation

### Standard Extension Setup
1. [Download](https://github.com/Max-Eee/Shim/archive/refs/heads/main.zip) the extension.
2. Open Chrome and go to the Extensions page by typing `chrome://extensions/`.
3. Enable **Developer mode** in the top right corner.
4. Click on **Load unpacked** and select the folder where the extension is located.

### Native Messaging Setup (Required for `isTrusted` Keyboard Bypass)
To enable undetectable physical typing, you must register the Native Host with your OS.
- **Windows Users**: Open the `native` folder inside the extension and double-click `setup_windows.bat`.
- **Mac Users**: Run `pip3 install pynput` in your terminal. Then run:
  ```bash
  mkdir -p ~/Library/Application\ Support/Google/Chrome/NativeMessagingHosts
  cp "/Path/To/Shim/native/host_manifest.json" ~/Library/Application\ Support/Google/Chrome/NativeMessagingHosts/com.shim.keyboard.json
  ```
Reload the extension in Chrome after setup!

### Installation Guide Video

https://github.com/user-attachments/assets/89fb986c-2edb-4252-8232-dbd10beec0cf


## 💻 Usage

### For Free Users:
1. Click the Shim extension icon in your browser toolbar
2. Navigate to the **Settings** tab
3. Enter your AI API key (OpenAI, Google Gemini, DeepSeek, or custom endpoint)
4. Select your AI provider from the dropdown menu
5. Click "Test Connection" to verify your setup
6. Start using all Shim features with your own API!

> [!NOTE]
> **Network Restrictions**: If your school/organization blocks AI service providers (OpenAI, Google, etc.), the extension will not work even with a valid API key. In this case, consider using a VPN or upgrade to Pro by visiting **shim.tech/pro**.

## ⌨️ Shortcuts

### Windows / Linux

**Supported Platforms**
- <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>T</kbd> : Type Platform Coding Answers (Uses Native Host)
- <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>A</kbd> : Search Platform Answers Using AI

**Universal**
- <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>S</kbd> : Search Answers Using AI (⚠️ *SELECT QUESTION FIRST*)
- <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>M</kbd> : Solve MCQs Using AI (⚠️ *SELECT QUESTION FIRST*)
- <kbd>Alt</kbd> + <kbd>C</kbd> : Toggle Chatbot Overlay
- <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>V</kbd> : Paste Using Drag and Drop

**HackerRank**
- <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>H</kbd> : Solve HackerRank Questions [BETA]

**NPTEL**
- <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>N</kbd> : Solve NPTEL MCQs (⚠️ *SELECT QUESTION FIRST*)

---

<details>
<summary><strong>Mac Users (Click to expand)</strong></summary>

**Supported Platforms**
- <kbd>Control</kbd> + <kbd>Shift</kbd> + <kbd>T</kbd> : Type Platform Coding Answers (Uses Native Host)
- <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>A</kbd> : Search Platform Answers Using AI

**Universal**
- <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>S</kbd> : Search Answers Using AI (⚠️ *SELECT QUESTION FIRST*)
- <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>M</kbd> : Solve MCQs Using AI (⚠️ *SELECT QUESTION FIRST*)
- <kbd>Option</kbd> + <kbd>C</kbd> : Toggle Chatbot Overlay
- <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>V</kbd> : Paste Using Drag and Drop

**HackerRank**
- <kbd>Control</kbd> + <kbd>Shift</kbd> + <kbd>H</kbd> : Solve HackerRank Questions [BETA]

**NPTEL**
- <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>N</kbd> : Solve NPTEL MCQs (⚠️ *SELECT QUESTION FIRST*)

</details>

## 🤝 Contribute or Add NPTEL Dataset

If you want to contribute to the NPTEL question database, follow these steps:
1. Fork this repository
2. Open your NPTEL assignment page in the browser
3. Open browser developer tools (F12 or right-click > Inspect)
4. Go to the Console tab
5. Copy and paste the script from `nptel.txt` in the repository
6. Run the script by pressing Enter
7. Copy the output JSON data
8. Update the `data/nptel.json` file with the new questions and answers
9. Create a pull request to contribute your additions back to the main repository

## 💬 Feedback

We'd love to hear your thoughts! If you encounter any issues or have suggestions for improvement, please reach out. Your feedback is invaluable! 💌

📧 **Contact us at:** [freeshim@gmail.com](mailto:freeshim@gmail.com?subject=Issue)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

</samp>
